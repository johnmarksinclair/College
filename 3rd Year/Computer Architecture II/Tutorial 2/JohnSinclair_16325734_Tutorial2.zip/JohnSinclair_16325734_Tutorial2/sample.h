#pragma once
// Function declaration

// A procedure to calculate sum of the array
extern "C" _int64 array_proc(_int64, _int64 array[]);

// A procedure to print the sum of two integers
extern "C" _int64 print_proc(_int64, _int64);
