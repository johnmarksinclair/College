#pragma once

extern "C" _int64 use_scanf(_int64, _int64, _int64);

extern "C" _int64 fibX64(_int64);

extern "C" _int64 max(_int64, _int64, _int64);

extern "C" _int64 max5(_int64, _int64, _int64, _int64);

extern "C" _int64 inp_int;

