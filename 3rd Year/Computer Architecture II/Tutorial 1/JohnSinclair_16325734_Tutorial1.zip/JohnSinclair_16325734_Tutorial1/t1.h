#pragma once

extern "C" int _cdecl array_proc(int array[], int);
extern "C" int _cdecl poly(int);
extern "C" int _cdecl factorial(int);
extern "C" int _cdecl multiple_k_asm(uint16_t, uint16_t, uint16_t*);

