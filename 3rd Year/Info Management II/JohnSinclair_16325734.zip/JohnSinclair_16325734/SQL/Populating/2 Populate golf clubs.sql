use GUI;

insert into Golf_Club (
    Name, 
    Address, 
    Phone_Number,
    Province_ID
)
values (
    'Carton House Golf Club',
    'Carton House, Carton Demesne, Maynooth, Co. Kildare',
    '(01) 651 7715',
    3
),
(
    'The K Club',
    'The K Club, Straffan, Co. Kildare',
    '(01) 601 7200',
    3
),
(
    'Adare Manor Golf Club',
    'Limerick Road, Adare, Co. Limerick',
    '(061) 396 204',
    4
),
(
    'Ballyliffin Golf Club',
    'Ballyliffin, Co. Donegal',
    '(074) 937 6119',
    5
),
(
    'Carne Golf Links',
    'Carne, Belmullet, Co. Mayo',
    '(097) 82292',
    2
);