use GUI;

insert into Province (
    Name,
    Phone_Number,
    Email
) values (
    'GUI National Headquarters',
    '+353 (0)1 5054000',
    'information@gui.ie'
),
(
    'Connacht Golf',
    '+353 (0)94 9028141',
    'info@connacht.gui.ie'
),
(
    'Leinster Golf',
    '+353 (0)1 6016842',
    'info@leinster.gui.ie'
),
(
    'Munster Golf',
    '+353 (0)22 21026',
    'info@munster.gui.ie'
),
(
    'Ulster Golf',
    '+44 (0)28 9049 1891',
    'info@connacht.gui.ie'
);
