use GUI;

insert into Competition_Entry (
    Player_ID,
    Competition_ID
)
values (
    1,
    1
),
(
    1,
    3
),

(
    7,
    5
),

(
    3,
    3
),

(
    4,
    3
),

(
    6,
    3
);