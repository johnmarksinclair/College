use GUI;

insert into Employee (
    First_name, 
    Last_Name, 
    Role, 
    Salary, 
    DOB, 
    Club_ID,
    Province_ID
)
values (
    'Kenny',
    'Fahy',
    'Head Professional',
    35000,
    '1984-03-14',
    NULL,
    1
),
(
    'Callum',
    'Slater',
    'Assistant Professional',
    21000,
    '1995-06-02',
    NULL,
    1
),
(
    'David',
    'Smith',
    'Head Professional',
    25000,
    '1983-06-02',
    1,
    NULL
),
(
    'Harry',
    'OBrien',
    'Assistant Professional',
    18000,
    '1993-06-02',
    1,
    NULL
),
(
    'David',
    'Lonergan',
    'Head Professional',
    28000,
    '1977-03-12',
    2,
    NULL
),
(
    'Jason',
    'Duggan',
    'Head Professional',
    31000,
    '1989-11-09',
    3,
    NULL
),
(
    'Adam',
    'Patrick',
    'Head Professional',
    29700,
    '1987-03-17',
    4,
    NULL
),
(
    'Connor',
    'Matthews',
    'Head Professional',
    27500,
    '1978-01-27',
    5,
    NULL
);