use GUI;

insert into Competition (
    Name,
    Date,
    Club_ID
)
values (
    'Captains Prize',
    '2021-06-12',
    1
),
(
    'Scratch Cup',
    '2020-08-12',
    1
),
(
    'Monthly Medal',
    '2021-01-07',
    1
),
(
    'Ryder Cup',
    '2027-09-28',
    3
),
(
    'Captains Prize',
    '2021-06-12',
    2
),
(
    'Monthly Medal',
    '2021-01-07',
    2
);